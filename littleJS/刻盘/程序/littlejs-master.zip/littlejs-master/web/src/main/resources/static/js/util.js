function delayUrl(url, time) {
    window.setTimeout("window.location.href = '" + url + "'", time);
}