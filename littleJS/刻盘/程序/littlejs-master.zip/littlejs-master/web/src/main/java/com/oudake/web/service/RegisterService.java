package com.oudake.web.service;

import com.oudake.common.ResultEntity;
import com.oudake.web.model.TblUser;

/**
 * @author wangyi
 */
public interface RegisterService {

    ResultEntity register(TblUser user);

}
