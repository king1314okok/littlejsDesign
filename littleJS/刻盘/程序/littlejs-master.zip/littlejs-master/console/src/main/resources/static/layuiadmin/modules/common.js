layui.define(function(e) {
    e("common");
});